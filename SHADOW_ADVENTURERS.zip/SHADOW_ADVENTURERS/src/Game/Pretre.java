package Game;

public class Pretre extends Personnage {
    public Pretre(String nom) {
        super(nom, 80, 8, 80, 3);
    }

    @Override
    public void attaquer(Personnage cible) {
        System.out.println(nom + " attaque " + cible.getNom() + " avec sa masse !");
        cible.recevoirDegats(degats);
    }

    @Override
    public void utiliserCompetence(Personnage cible) {
        if (consommerMana(10)) {
            System.out.println(nom + " utilise une compétence spéciale : Soin !");
            cible.recevoirSoin(degats);
        }
    }
}
