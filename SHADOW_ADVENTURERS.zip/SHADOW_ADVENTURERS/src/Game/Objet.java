/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

 package Game;

 public class Objet {
     private String nom;
     private String type; // "soin", "buff"
     private int valeur;
 
     public Objet(String nom, String type, int valeur) {
         this.nom = nom;
         this.type = type;
         this.valeur = valeur;
     }
 
     public void utiliser(Personnage cible) {
         switch (type) {
             case "soin":
                 cible.recevoirSoin(valeur);
                 break;
             case "buff":
                 cible.ameliorerDegats(valeur);
                 break;
         }
     }
 }
 
