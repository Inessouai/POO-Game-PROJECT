package Game;

public class Archer extends Personnage {
    public Archer(String nom) {
        super(nom, 90, 12, 40, 3);
    }

    @Override
    public void attaquer(Personnage cible) {
        System.out.println(nom + " tire une flèche sur " + cible.getNom() + " !");
        cible.recevoirDegats(degats);
    }

    @Override
    public void utiliserCompetence(Personnage cible) {
        if (consommerMana(15)) {
            System.out.println(nom + " utilise une compétence spéciale : Tir précis !");
            cible.recevoirDegats(degats + 15);
        }
    }
}
