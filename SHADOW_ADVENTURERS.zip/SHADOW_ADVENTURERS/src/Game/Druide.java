package Game;

public class Druide extends Personnage {
    public Druide(String nom) {
        super(nom, 85, 10, 80, 3);
    }

    @Override
    public void attaquer(Personnage cible) {
        System.out.println(nom + " invoque la nature pour attaquer " + cible.getNom() + " !");
        cible.recevoirDegats(degats);
    }

    @Override
    public void utiliserCompetence(Personnage cible) {
        if (consommerMana(20)) {
            System.out.println(nom + " utilise une compétence spéciale : Croissance sauvage !");
            cible.recevoirDegats(degats + 20);
        }
    }
}
