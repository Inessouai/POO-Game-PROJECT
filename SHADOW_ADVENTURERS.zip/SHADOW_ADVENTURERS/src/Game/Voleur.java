package Game;

public class Voleur extends Personnage {
    public Voleur(String nom) {
        super(nom, 80, 10, 50, 2);
    }

    @Override
    public void attaquer(Personnage cible) {
        System.out.println(nom + " poignarde " + cible.getNom() + " !");
        cible.recevoirDegats(degats);
    }

    @Override
    public void utiliserCompetence(Personnage cible) {
        if (consommerMana(15)) {
            System.out.println(nom + " utilise une compétence spéciale : Attaque furtive !");
            cible.recevoirDegats(degats + 15);
        }
    }
}
