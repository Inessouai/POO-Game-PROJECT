package Game;

import java.util.Scanner;

public class Play02 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        Personnage archer = new Archer("Robin");
        Personnage druide = new Druide("Elwynn");
        Personnage moine = new Moine("Chen");
        Personnage pretre = new Pretre("Anduin");
        Personnage voleur = new Voleur("Loki");
        Personnage mage = new Mage("Floki");

        Objet potion = new Objet("Potion de vie", "soin", 30);
        Objet potionForce = new Objet("Potion de force", "buff", 5);

        System.out.println("Choisissez votre personnage :");
        System.out.println("1. Archer");
        System.out.println("2. Druide");
        System.out.println("3. Moine");
        System.out.println("4. Prêtre");
        System.out.println("5. Voleur");
        System.out.println("6. Mage");

        int choix = scanner.nextInt();
        Personnage joueur;
        switch (choix) {
            case 1:
                joueur = archer;
                break;
            case 2:
                joueur = druide;
                break;
            case 3:
                joueur = moine;
                break;
            case 4:
                joueur = pretre;
                break;
            case 5:
                joueur = voleur;
                break;
            case 6:
                joueur = mage;
                break;
            default:
                System.out.println("Choix invalide. L'archer est sélectionné par défaut.");
                joueur = archer;
                break;
        }

        while (archer.estVivant() && druide.estVivant() && moine.estVivant() && pretre.estVivant() && voleur.estVivant() && mage.estVivant()) {
            System.out.println("\n--- Tour de combat ---");
            System.out.println("1. Attaquer");
            System.out.println("2. Utiliser compétence");
            System.out.println("3. Utiliser un objet");
            System.out.println("4. Passer son tour");

            int action = scanner.nextInt();

            switch (action) {
                case 1:
                    System.out.println("Choisissez un adversaire :");
                    System.out.println("1. Druide");
                    System.out.println("2. Moine");
                    System.out.println("3. Prêtre");
                    System.out.println("4. Voleur");
                    System.out.println("5. Mage");
                    int cible = scanner.nextInt();
                    if (cible == 1 && druide.estVivant()) joueur.attaquer(druide);
                    else if (cible == 2 && moine.estVivant()) joueur.attaquer(moine);
                    else if (cible == 3 && pretre.estVivant()) joueur.attaquer(pretre);
                    else if (cible == 4 && voleur.estVivant()) joueur.attaquer(voleur);
                    else if (cible == 5 && mage.estVivant()) joueur.attaquer(mage);
                    break;
                case 2:
                    System.out.println("Choisissez un adversaire :");
                    System.out.println("1. Druide");
                    System.out.println("2. Moine");
                    System.out.println("3. Prêtre");
                    System.out.println("4. Voleur");
                    System.out.println("5. Mage");
                    cible = scanner.nextInt();
                    if (cible == 1 && druide.estVivant()) joueur.utiliserCompetence(druide);
                    else if (cible == 2 && moine.estVivant()) joueur.utiliserCompetence(moine);
                    else if (cible == 3 && pretre.estVivant()) joueur.utiliserCompetence(pretre);
                    else if (cible == 4 && voleur.estVivant()) joueur.utiliserCompetence(voleur);
                    else if (cible == 5 && mage.estVivant()) joueur.utiliserCompetence(mage);
                    break;
                case 3:
                    System.out.println("1. Potion de vie");
                    System.out.println("2. Potion de force");
                    int objetChoisi = scanner.nextInt();
                    if (objetChoisi == 1) potion.utiliser(joueur);
                    else if (objetChoisi == 2) potionForce.utiliser(joueur);
                    break;
                case 4:
                    System.out.println(joueur.getNom() + " passe son tour.");
                    break;
                default:
                    System.out.println("Action invalide.");
                    break;
            }

            if (druide.estVivant()) {
                druide.attaquer(joueur);
            }
            if (moine.estVivant()) {
                moine.attaquer(joueur);
            }
            if (pretre.estVivant()) {
                pretre.attaquer(joueur);
            }
            if (voleur.estVivant()) {
                voleur.attaquer(joueur);
            }
            if (mage.estVivant()) {
                mage.attaquer(joueur);
            }

            if (!joueur.estVivant()) {
                System.out.println(joueur.getNom() + " est mort !");
                break;
            }
        }

        scanner.close();
        System.out.println("Fin du jeu.");
    }
}
