package Game;

public class Moine extends Personnage {
    public Moine(String nom) {
        super(nom, 90, 8, 50, 4);
    }

    @Override
    public void attaquer(Personnage cible) {
        System.out.println(nom + " attaque avec un coup de poing puissant " + cible.getNom() + " !");
        cible.recevoirDegats(degats);
    }

    @Override
    public void utiliserCompetence(Personnage cible) {
        if (consommerMana(15)) {
            System.out.println(nom + " utilise une compétence spéciale : Poing de fer !");
            cible.recevoirDegats(degats + 15);
        }
    }
}
