package Game;

public class Guerrier extends Personnage {
    public Guerrier(String nom) {
        super(nom, 120, 10, 50, 5);
    }

    @Override
    public void attaquer(Personnage cible) {
        System.out.println(nom + " attaque " + cible.getNom() + " !");
        cible.recevoirDegats(degats);
    }

    @Override
    public void utiliserCompetence(Personnage cible) {
        if (consommerMana(20)) {
            System.out.println(nom + " utilise sa compétence spéciale : Coup de rage !");
            cible.recevoirDegats(degats * 2);
        }
    }
}


