package Game;

public abstract class Personnage implements Attaquable {
    protected String nom;
    protected int pointsDeVie;
    protected int degats;
    protected int niveau;
    protected int experience;
    protected int mana;
    protected int armure;

    public Personnage(String nom, int pointsDeVie, int degats, int mana, int armure) {
        this.nom = nom;
        this.pointsDeVie = pointsDeVie;
        this.degats = degats;
        this.niveau = 1;
        this.experience = 0;
        this.mana = mana;
        this.armure = armure;
    }

    public void recevoirDegats(int degats) {
        int degatsReels = Math.max(degats - armure, 0);
        pointsDeVie -= degatsReels;
        System.out.println(nom + " a reçu " + degatsReels + " points de dégâts. Points de vie restants : " + pointsDeVie);
    }

    public boolean estVivant() {
        return pointsDeVie > 0;
    }

    public String getNom() {
        return nom;
    }

    public void recevoirSoin(int points) {
        pointsDeVie += points;
        System.out.println(nom + " récupère " + points + " points de vie.");
    }

    public void ameliorerDegats(int bonus) {
        degats += bonus;
        System.out.println(nom + " gagne un bonus de " + bonus + " dégâts.");
    }

    public void gagnerExperience(int xp) {
        experience += xp;
        if (experience >= 100) {
            niveau++;
            experience = 0;
            pointsDeVie += 20;
            degats += 5;
            System.out.println(nom + " a atteint le niveau " + niveau + " !");
        }
    }

    protected boolean consommerMana(int cout) {
        if (mana >= cout) {
            mana -= cout;
            return true;
        } else {
            System.out.println(nom + " n'a pas assez de mana !");
            return false;
        }
    }
}

